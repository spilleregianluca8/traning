import { useEffect, useMemo, useRef, useState } from 'react'
import {
  Dumbbell, CalendarDays, TrendingUp, Settings, Plus, ChevronLeft, ChevronRight, X, Check,
  ArrowUp, ArrowDown, Copy, Trash2, ClipboardPaste, Download, Upload, ListOrdered,
  Users, Share2, Pencil, ChevronDown, UserPlus, Send, Search,
} from 'lucide-react'

/* ================= Konštanty ================= */
const STORAGE_KEY = 'trening-dennik-v1'
const DAYS = ['Po', 'Ut', 'St', 'Št', 'Pi', 'So', 'Ne']
const DAYL = ['Pondelok', 'Utorok', 'Streda', 'Štvrtok', 'Piatok', 'Sobota', 'Nedeľa']
const MON = ['jan', 'feb', 'mar', 'apr', 'máj', 'jún', 'júl', 'aug', 'sep', 'okt', 'nov', 'dec']
const MONL = ['Január', 'Február', 'Marec', 'Apríl', 'Máj', 'Jún', 'Júl', 'August', 'September', 'Október', 'November', 'December']

const SECTIONS = [
  { key: 'wu', label: 'Rozcvička', pill: 'text-violet-700 bg-violet-100 dark:text-violet-300 dark:bg-violet-950' },
  { key: 'plyo', label: 'Plyo', pill: 'text-amber-700 bg-amber-100 dark:text-amber-300 dark:bg-amber-950' },
  { key: 'main', label: 'Hlavná časť', pill: 'text-blue-700 bg-blue-100 dark:text-blue-300 dark:bg-blue-950' },
  { key: 'cap', label: 'Kapacita', pill: 'text-teal-700 bg-teal-100 dark:text-teal-300 dark:bg-teal-950' },
]

/* Prvé tréningy, ktoré sa načítajú pri úplne prvom spustení */
const SEED = [
  {
    id: 'jednotka-a-2026-11-09', date: '2026-11-09', title: 'Jednotka A', status: 'planned', note: '',
    exercises: [
      ['wu', 'Rozdýchanie (v ľahu + na štyroch)', "2'"], ['wu', 'Trup – strecha/cobra, open book', ''],
      ['wu', 'Bedrá – 90/90, žaba', ''], ['wu', 'Členok – knee to hamstring', '5x'], ['wu', 'Glute bridge', '10x'],
      ['plyo', 'Line hops (dopredu/dozadu + doprava/doľava)', '2x10/10'], ['plyo', 'Pogo jumps', '2x10'],
      ['plyo', 'Drop catch (30 cm)', '2x5'], ['plyo', 'CMJ', '2x5'],
      ['main', 'Goblet SQ', '5x5 16 kg KTB'], ['main', 'Pull ups', '4-3-3'], ['main', 'RDL', '5x5 35 kg'],
      ['cap', 'Výpony jednonož', '3x3x108 kg'], ['cap', 'Copenhagen plank (koleno na lavičke)', '2x 20/20" 8 kg'],
    ],
  },
  {
    id: 'jednotka-b-2026-11-13', date: '2026-11-13', title: 'Jednotka B', status: 'planned', note: '',
    exercises: [
      ['wu', 'Rozdýchanie (v ľahu + na štyroch)', "2'"], ['wu', 'Trup – strecha/cobra, open book', ''],
      ['wu', 'Bedrá – 90/90, žaba', ''], ['wu', 'Členok – knee to hamstring', ''], ['wu', 'Glute bridge', '10x'],
      ['plyo', 'Line hops (dopredu/dozadu + doprava/doľava)', '2x10/10'], ['plyo', 'Pogo jumps', '2x10'],
      ['plyo', 'CMJ', '2x5'], ['plyo', 'SL box jump (35 cm)', '2x5+5'],
      ['main', 'Goblet SQ', '3x5 20 kg'], ['main', 'Landmine press', '3x5+5 22,5/25 kg'], ['main', 'RDL', '6x5 35 kg'],
      ['cap', 'Výpony v sede', '2x10,10'], ['cap', 'Hip flexory na lavičke', '3x(5+5) BW / 3–5 kg medball'],
    ],
  },
].map((s) => ({ ...s, clientId: 'me', updatedAt: 0, exercises: s.exercises.map(([section, name, dose]) => ({ section, name, dose })) }))

/* ================= Dátumy ================= */
const pad = (n) => String(n).padStart(2, '0')
const iso = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`
const parseDate = (s) => { const [y, m, d] = s.split('-').map(Number); return new Date(y, m - 1, d) }
const addDays = (d, n) => { const x = new Date(d); x.setDate(x.getDate() + n); return x }
const mondayOf = (d) => { const x = new Date(d.getFullYear(), d.getMonth(), d.getDate()); x.setDate(x.getDate() - ((x.getDay() + 6) % 7)); return x }
const dow = (d) => (d.getDay() + 6) % 7
const fmt = (d) => `${d.getDate()}. ${MON[d.getMonth()]}`
const isoWeek = (d) => {
  const t = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()))
  const day = t.getUTCDay() || 7
  t.setUTCDate(t.getUTCDate() + 4 - day)
  const y = new Date(Date.UTC(t.getUTCFullYear(), 0, 1))
  return Math.ceil(((t - y) / 864e5 + 1) / 7)
}
const uid = () => Math.random().toString(36).slice(2, 10) + Date.now().toString(36)
const kgOf = (dose) => { const m = String(dose || '').match(/(\d+(?:[.,]\d+)?)\s*kg/i); return m ? parseFloat(m[1].replace(',', '.')) : 0 }

/* ================= Ukladanie (localStorage) ================= */
function loadState() {
  let d = null
  try {
    const raw = localStorage.getItem(STORAGE_KEY)
    if (raw) d = JSON.parse(raw)
  } catch { /* poškodené alebo zablokované úložisko */ }
  if (!d || !Array.isArray(d.sessions)) d = { sessions: SEED, clients: [{ id: 'me', name: 'Ja' }] }
  return normalizeData(d)
}

const cleanClient = (c) => ({ id: String(c.id || uid()), name: String(c.name || 'Klient').slice(0, 60) })

/* Zjednotí tvar dát; staršie verzie bez klientov presunie pod klienta „Ja“ */
function normalizeData(d) {
  let clients = Array.isArray(d.clients) ? d.clients.map(cleanClient) : []
  if (!clients.length) clients = [{ id: 'me', name: 'Ja' }]
  const ids = new Set(clients.map((c) => c.id))
  const sessions = (d.sessions || []).map((x) => {
    const c = cleanSession(x)
    if (!ids.has(c.clientId)) c.clientId = clients[0].id
    return c
  })
  return {
    version: 2,
    settings: d.settings || {},
    clients,
    activeClientId: ids.has(d.activeClientId) ? d.activeClientId : clients[0].id,
    sessions,
  }
}

function cleanSession(s) {
  return {
    id: String(s.id || uid()),
    clientId: String(s.clientId || ''),
    date: String(s.date || iso(new Date())),
    title: String(s.title || ''),
    status: s.status === 'done' ? 'done' : 'planned',
    note: String(s.note || ''),
    updatedAt: Number(s.updatedAt) || 0,
    exercises: (Array.isArray(s.exercises) ? s.exercises : [])
      .map((e) => ({
        section: SECTIONS.some((x) => x.key === e.section) ? e.section : 'main',
        name: String(e.name || ''),
        dose: String(e.dose || ''),
      }))
      .filter((e) => e.name || e.dose),
  }
}

/* ================= Vloženie textu z dokumentu ================= */
const SEC_RX = [
  ['wu', /^(wu\b|warm|rozcvi|rozd[ýy]ch|mobilit|aktiv)/i],
  ['plyo', /^plyo/i],
  ['main', /^(hlavn|main\b|silov)/i],
  ['cap', /^kapacit/i],
]
function splitItem(t) {
  let i = t.indexOf(':')
  if (i > 0 && i < t.length - 1) return [t.slice(0, i).trim(), t.slice(i + 1).trim()]
  i = Math.max(t.lastIndexOf(' - '), t.lastIndexOf(' – '))
  if (i > 0 && /\d/.test(t.slice(i + 3))) return [t.slice(0, i).trim(), t.slice(i + 3).trim()]
  const m = t.match(/^(.*?\D)\s+(\d+\s*[x×].*)$/i)
  if (m) return [m[1].trim(), m[2].trim()]
  return [t.trim(), '']
}
function parseText(txt, fallbackDate) {
  const out = []
  let cur = null
  let sec = 'wu'
  const ensure = () => {
    if (!cur) { cur = { id: uid(), date: fallbackDate, title: 'Tréning', status: 'planned', note: '', exercises: [] }; out.push(cur) }
  }
  for (const raw of txt.split(/\r?\n/)) {
    const t = raw.replace(/^[\s\-•●▪*–·]+/, '').trim()
    if (!t) continue
    const dm = t.match(/(\d{1,2})\.\s*(\d{1,2})\.\s*(\d{4})/)
    if (dm && !/\d+\s*[x×]/i.test(t)) {
      const title = t.replace(/\(.*?\)/g, '').replace(/[:\s]+$/, '').replace(/^Tréningová\s+/i, '').replace(/^jednotka/i, 'Jednotka').trim()
      cur = { id: uid(), date: `${dm[3]}-${pad(+dm[2])}-${pad(+dm[1])}`, title: title || 'Tréning', status: 'planned', note: '', exercises: [] }
      out.push(cur)
      sec = 'wu'
      continue
    }
    if (/^\d+\.\s*t[ýy]d/i.test(t)) continue
    const hit = SEC_RX.find(([, rx]) => rx.test(t))
    if (hit) {
      sec = hit[0]
      const m = t.match(/^\S+?\s*[:\-–]\s*(.+)$/)
      if (!m) continue
      ensure()
      cur.exercises.push({ section: sec, name: t.split(/\s*[:\-–]\s*/)[0].trim(), dose: m[1].trim() })
      continue
    }
    ensure()
    const [name, dose] = splitItem(t)
    cur.exercises.push({ section: sec, name, dose })
  }
  return out.filter((s) => s.exercises.length)
}

/* ================= Malé UI prvky ================= */
const card = 'rounded-2xl bg-white shadow-sm ring-1 ring-slate-200/70 dark:bg-slate-900 dark:ring-slate-800'
const btnPri = 'h-12 rounded-xl bg-accent px-5 font-bold text-white active:scale-[.97] transition'
const btnSec = 'h-12 rounded-xl bg-slate-200/70 px-5 font-bold text-slate-800 active:scale-[.97] transition dark:bg-slate-800 dark:text-slate-100'
const iconBtn = 'grid h-11 w-11 shrink-0 place-items-center rounded-full bg-white shadow-sm ring-1 ring-slate-200 active:scale-95 dark:bg-slate-900 dark:ring-slate-800'
const input = 'w-full min-w-0 rounded-xl border border-slate-200 bg-white px-3 py-2.5 dark:border-slate-700 dark:bg-slate-900'

function Pill({ section }) {
  const s = SECTIONS.find((x) => x.key === section)
  return <span className={`inline-block rounded-md px-2 py-0.5 text-[11px] font-extrabold uppercase tracking-wider ${s.pill}`}>{s.label}</span>
}

function Empty({ title, children }) {
  return (
    <div className={`${card} px-6 py-10 text-center`}>
      <h2 className="mb-1 text-lg font-extrabold">{title}</h2>
      <div className="text-sm text-slate-500 dark:text-slate-400">{children}</div>
    </div>
  )
}

function Sheet({ title, onClose, actions, children }) {
  return (
    <div className="fixed inset-0 z-40 overflow-y-auto bg-slate-100 dark:bg-[#0e1117]">
      <div className="pt-safe sticky top-0 z-10 bg-slate-100/95 backdrop-blur dark:bg-[#0e1117]/95">
        <div className="px-safe mx-auto flex max-w-xl items-center gap-2 py-3">
          <button className={iconBtn} onClick={onClose} aria-label="Zavrieť"><X size={20} /></button>
          <h2 className="min-w-0 flex-1 truncate text-xl font-extrabold">{title}</h2>
          {actions}
        </div>
      </div>
      <div className="px-safe mx-auto grid max-w-xl gap-3 pb-[calc(32px+env(safe-area-inset-bottom))] pt-1">{children}</div>
    </div>
  )
}

/* ================= Aplikácia ================= */
export default function App() {
  const [data, setData] = useState(loadState)
  const [tab, setTab] = useState('week')
  const [weekStart, setWeekStart] = useState(() => mondayOf(new Date()))
  const [calMonth, setCalMonth] = useState(() => new Date(new Date().getFullYear(), new Date().getMonth(), 1))
  const [sheet, setSheet] = useState(null) // {kind:'edit', session} | {kind:'paste'}
  const [fabOpen, setFabOpen] = useState(false)
  const [toast, setToast] = useState('')
  const [storageOk, setStorageOk] = useState(true)

  // Automatické ukladanie pri každej zmene
  useEffect(() => {
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(data)); setStorageOk(true) } catch { setStorageOk(false) }
  }, [data])

  // Požiadať prehliadač, aby dáta nemazal pri nedostatku miesta
  useEffect(() => { navigator.storage?.persist?.().catch(() => {}) }, [])

  useEffect(() => { if (!toast) return; const t = setTimeout(() => setToast(''), 2500); return () => clearTimeout(t) }, [toast])
  useEffect(() => { document.body.style.overflow = sheet ? 'hidden' : '' }, [sheet])

  const client = data.clients.find((c) => c.id === data.activeClientId) || data.clients[0]
  const sessions = useMemo(() => data.sessions.filter((s) => s.clientId === client.id), [data.sessions, client.id])
  const byDate = useMemo(() => {
    const m = {}
    sessions.forEach((s) => { (m[s.date] ||= []).push(s) })
    return m
  }, [sessions])

  const upsert = (s) => setData((d) => {
    const clean = cleanSession({ ...s, clientId: s.clientId || client.id, updatedAt: Date.now() })
    const exists = d.sessions.some((x) => x.id === clean.id)
    return { ...d, sessions: exists ? d.sessions.map((x) => (x.id === clean.id ? clean : x)) : [...d.sessions, clean] }
  })
  const addMany = (list) => setData((d) => ({ ...d, sessions: [...d.sessions, ...list.map((s) => cleanSession({ ...s, id: uid(), clientId: client.id, updatedAt: Date.now() }))] }))
  const remove = (id) => setData((d) => ({ ...d, sessions: d.sessions.filter((x) => x.id !== id) }))
  const toggle = (id) => setData((d) => ({ ...d, sessions: d.sessions.map((x) => (x.id === id ? { ...x, status: x.status === 'done' ? 'planned' : 'done', updatedAt: Date.now() } : x)) }))
  const shifted = (s, days) => ({ ...s, id: uid(), date: iso(addDays(parseDate(s.date), days)), status: 'planned', note: '' })

  const selectClient = (id) => { setData((d) => ({ ...d, activeClientId: id })); setWeekStart(mondayOf(new Date())); setTab('week'); window.scrollTo(0, 0) }
  const addClient = (name) => {
    const id = uid()
    setData((d) => ({ ...d, clients: [...d.clients, { id, name }], activeClientId: id }))
    setToast(`Klient ${name} pridaný`)
  }
  const renameClient = (id, name) => setData((d) => ({ ...d, clients: d.clients.map((c) => (c.id === id ? { ...c, name } : c)) }))
  const deleteClient = (id) => setData((d) => {
    const clients = d.clients.filter((c) => c.id !== id)
    return { ...d, clients, sessions: d.sessions.filter((s) => s.clientId !== id), activeClientId: d.activeClientId === id ? clients[0].id : d.activeClientId }
  })

  const go = (t) => { setTab(t); setFabOpen(false); window.scrollTo(0, 0) }
  const openDay = (k) => { setWeekStart(mondayOf(parseDate(k))); go('week') }

  return (
    <div className="min-h-[100dvh]">
      {!storageOk && (
        <div className="pt-safe bg-red-600 px-4 py-2 text-center text-sm font-semibold text-white">
          Dáta sa nedajú uložiť (súkromný režim prehliadača?). Zálohuj si ich v Nastaveniach.
        </div>
      )}

      <main className="px-safe mx-auto max-w-xl pb-[calc(170px+env(safe-area-inset-bottom))]">
        {tab === 'clients' && (
          <ClientsView
            clients={data.clients} allSessions={data.sessions} activeId={client.id}
            onSelect={selectClient} onAdd={addClient}
            onEdit={(c) => setSheet({ kind: 'client', client: c })}
            onShare={(c) => setSheet({ kind: 'share', client: c })}
          />
        )}
        {tab === 'week' && (
          <WeekView
            client={client} onClients={() => go('clients')}
            weekStart={weekStart} setWeekStart={setWeekStart} sessions={sessions} byDate={byDate}
            onOpen={(s) => setSheet({ kind: 'edit', session: s })} onToggle={toggle}
            onCopyPrev={() => {
              const a = iso(addDays(weekStart, -7)), b = iso(addDays(weekStart, -1))
              addMany(sessions.filter((s) => s.date >= a && s.date <= b).map((s) => shifted(s, 7)))
              setToast('Minulý týždeň skopírovaný')
            }}
          />
        )}
        {tab === 'cal' && <CalendarView client={client} calMonth={calMonth} setCalMonth={setCalMonth} byDate={byDate} sessions={sessions} onDay={openDay} />}
        {tab === 'prog' && <ProgressView client={client} sessions={sessions} onOpen={(s) => setSheet({ kind: 'edit', session: s })} />}
        {tab === 'set' && <SettingsView data={data} setData={setData} setToast={setToast} />}
      </main>

      {/* Tlačidlo + a jeho menu */}
      {tab === 'week' && (
        <>
          {fabOpen && (
            <>
              <button className="fixed inset-0 z-20 cursor-default" aria-label="Zavrieť menu" onClick={() => setFabOpen(false)} />
              <div className="fixed bottom-[calc(156px+env(safe-area-inset-bottom))] right-[max(18px,env(safe-area-inset-right))] z-30 grid w-64 gap-1 rounded-2xl bg-white p-2 shadow-xl ring-1 ring-slate-200 dark:bg-slate-900 dark:ring-slate-800">
                <MenuItem icon={<Plus size={20} />} title="Nový tréning" sub="Prázdny tréning so sekciami"
                  onClick={() => { setFabOpen(false); setSheet({ kind: 'edit', session: null }) }} />
                <MenuItem icon={<ClipboardPaste size={20} />} title="Vložiť text" sub="Skopíruj týždeň z dokumentu"
                  onClick={() => { setFabOpen(false); setSheet({ kind: 'paste' }) }} />
              </div>
            </>
          )}
          <button
            onClick={() => setFabOpen((v) => !v)} aria-label="Pridať tréning" aria-expanded={fabOpen}
            className="fixed bottom-[calc(86px+env(safe-area-inset-bottom))] right-[max(18px,env(safe-area-inset-right))] z-30 grid h-16 w-16 place-items-center rounded-full bg-accent text-white shadow-lg shadow-accent/30 transition active:scale-95"
          >
            {fabOpen ? <X size={28} /> : <Plus size={30} />}
          </button>
        </>
      )}

      {/* Spodná navigácia */}
      <nav className="pb-safe fixed inset-x-0 bottom-0 z-20 border-t border-slate-200 bg-white/95 backdrop-blur dark:border-slate-800 dark:bg-slate-900/95">
        <div className="mx-auto grid max-w-xl grid-cols-5 px-[max(4px,env(safe-area-inset-left))]">
          <NavBtn active={tab === 'clients'} onClick={() => go('clients')} icon={<Users size={24} />} label="Klienti" />
          <NavBtn active={tab === 'week'} onClick={() => go('week')} icon={<Dumbbell size={24} />} label="Tréningy" />
          <NavBtn active={tab === 'cal'} onClick={() => { setCalMonth(new Date(weekStart.getFullYear(), weekStart.getMonth(), 1)); go('cal') }} icon={<CalendarDays size={24} />} label="Kalendár" />
          <NavBtn active={tab === 'prog'} onClick={() => go('prog')} icon={<TrendingUp size={24} />} label="Progres" />
          <NavBtn active={tab === 'set'} onClick={() => go('set')} icon={<Settings size={24} />} label="Nastavenia" />
        </div>
      </nav>

      {sheet?.kind === 'edit' && (
        <Editor
          session={sheet.session} weekStart={weekStart} sessions={data.sessions}
          onClose={() => setSheet(null)}
          onSave={(s) => { upsert(s); setWeekStart(mondayOf(parseDate(s.date))); setSheet(null); setToast('Uložené') }}
          onDuplicate={(s) => { const c = shifted(s, 7); addMany([c]); setWeekStart(mondayOf(parseDate(c.date))); setSheet(null); setToast('Skopírované na ďalší týždeň') }}
          onDelete={(id) => { remove(id); setSheet(null); setToast('Tréning vymazaný') }}
        />
      )}
      {sheet?.kind === 'client' && (
        <ClientSheet
          client={sheet.client} count={data.sessions.filter((s) => s.clientId === sheet.client.id).length}
          canDelete={data.clients.length > 1} onClose={() => setSheet(null)}
          onSave={(name) => { renameClient(sheet.client.id, name); setSheet(null); setToast('Uložené') }}
          onDelete={() => { deleteClient(sheet.client.id); setSheet(null); setToast('Klient vymazaný') }}
        />
      )}
      {sheet?.kind === 'share' && (
        <ShareSheet
          client={sheet.client} sessions={data.sessions.filter((s) => s.clientId === sheet.client.id)}
          onClose={() => setSheet(null)} setToast={setToast}
        />
      )}
      {sheet?.kind === 'paste' && (
        <PasteSheet
          fallbackDate={iso(weekStart)} onClose={() => setSheet(null)}
          onImport={(list) => { addMany(list); setWeekStart(mondayOf(parseDate(list[0].date))); setSheet(null); setToast(`Pridané tréningy: ${list.length}`) }}
        />
      )}

      {toast && (
        <div className="pointer-events-none fixed inset-x-0 bottom-[calc(170px+env(safe-area-inset-bottom))] z-50 flex justify-center px-4">
          <div className="rounded-full bg-slate-900 px-4 py-2 text-sm font-semibold text-white shadow-lg dark:bg-white dark:text-slate-900">{toast}</div>
        </div>
      )}
    </div>
  )
}

function NavBtn({ active, onClick, icon, label }) {
  return (
    <button onClick={onClick} aria-current={active ? 'page' : undefined}
      className={`flex min-h-[64px] min-w-0 flex-col items-center justify-center gap-1 text-[11px] font-bold ${active ? 'text-accent dark:text-accent-dark' : 'text-slate-500 dark:text-slate-400'}`}>
      {icon}{label}
    </button>
  )
}

function MenuItem({ icon, title, sub, onClick }) {
  return (
    <button onClick={onClick} className="flex items-center gap-3 rounded-xl px-3 py-3 text-left active:bg-slate-100 dark:active:bg-slate-800">
      <span className="text-accent">{icon}</span>
      <span><span className="block font-bold">{title}</span><span className="block text-xs text-slate-500 dark:text-slate-400">{sub}</span></span>
    </button>
  )
}

/* ================= Týždeň ================= */
function WeekView({ client, onClients, weekStart, setWeekStart, sessions, byDate, onOpen, onToggle, onCopyPrev }) {
  const end = addDays(weekStart, 6)
  const today = iso(new Date())
  const isNow = iso(mondayOf(new Date())) === iso(weekStart)
  const a = iso(weekStart), b = iso(end)
  const week = sessions.filter((s) => s.date >= a && s.date <= b).sort((x, y) => x.date.localeCompare(y.date) || x.title.localeCompare(y.title))
  const hasPrev = sessions.some((s) => s.date >= iso(addDays(weekStart, -7)) && s.date < a)

  return (
    <>
      <header className="pt-safe">
        <div className="flex justify-center pt-3">
          <button onClick={onClients} className="flex h-10 max-w-full items-center gap-2 rounded-full bg-white px-4 font-bold shadow-sm ring-1 ring-slate-200 active:scale-95 dark:bg-slate-900 dark:ring-slate-800">
            <Users size={16} className="shrink-0 text-accent" /><span className="truncate">{client.name}</span><ChevronDown size={16} className="shrink-0 text-slate-400" />
          </button>
        </div>
        <div className="mt-2 flex items-center gap-3">
          <button className={iconBtn} onClick={() => setWeekStart(addDays(weekStart, -7))} aria-label="Predchádzajúci týždeň"><ChevronLeft size={22} /></button>
          <div className="min-w-0 flex-1 text-center">
            <h1 className="text-[28px] font-black leading-tight">Týždeň {isoWeek(weekStart)}</h1>
            <div className="text-sm font-medium text-slate-500 dark:text-slate-400">{fmt(weekStart)} – {fmt(end)} {end.getFullYear()}</div>
          </div>
          <button className={iconBtn} onClick={() => setWeekStart(addDays(weekStart, 7))} aria-label="Ďalší týždeň"><ChevronRight size={22} /></button>
        </div>

        <div className="mt-4 grid grid-cols-7 gap-1.5">
          {DAYS.map((label, i) => {
            const d = addDays(weekStart, i), k = iso(d), ss = byDate[k] || []
            const done = ss.length && ss.every((s) => s.status === 'done')
            return (
              <button key={k} onClick={() => document.getElementById(`d-${k}`)?.scrollIntoView({ behavior: 'smooth', block: 'start' })}
                className={`grid min-h-[60px] justify-items-center gap-0.5 rounded-xl py-1.5 ${ss.length ? 'bg-white shadow-sm ring-1 ring-slate-200/70 dark:bg-slate-900 dark:ring-slate-800' : ''}`}>
                <small className={`text-[11px] font-bold uppercase ${k === today ? 'text-accent' : 'text-slate-500 dark:text-slate-400'}`}>{label}</small>
                <strong className={`text-base font-bold tabular-nums ${k === today ? 'text-accent' : ''}`}>{d.getDate()}</strong>
                <i className={`h-1.5 w-1.5 rounded-full ${ss.length ? (done ? 'bg-green-600 dark:bg-green-400' : 'bg-slate-400') : 'bg-transparent'}`} />
              </button>
            )
          })}
        </div>
        {!isNow && (
          <div className="mt-2 text-center">
            <button onClick={() => setWeekStart(mondayOf(new Date()))} className="rounded-full bg-accent-soft px-4 py-2 text-xs font-bold text-accent dark:bg-orange-950 dark:text-accent-dark">Späť na tento týždeň</button>
          </div>
        )}
      </header>

      <div className="mt-4 grid gap-3">
        {week.length === 0 ? (
          <Empty title="Žiadny tréning">
            Ťukni na + a pridaj tréning alebo vlož text z dokumentu.
            {hasPrev && <div className="mt-4"><button className={btnSec} onClick={onCopyPrev}>Skopírovať minulý týždeň</button></div>}
          </Empty>
        ) : week.map((s) => <SessionCard key={s.id} s={s} onOpen={() => onOpen(s)} onToggle={() => onToggle(s.id)} />)}
      </div>
    </>
  )
}

function SessionCard({ s, onOpen, onToggle }) {
  const d = parseDate(s.date)
  const ex = s.exercises.filter((e) => e.name)
  const done = s.status === 'done'
  return (
    <article id={`d-${s.date}`} className={`${card} scroll-mt-4 overflow-hidden`}>
      <div className="flex items-center gap-3 p-4 pb-3">
        <button onClick={onOpen} className="flex min-w-0 flex-1 items-center gap-3 text-left">
          <div className="grid h-14 w-12 shrink-0 place-content-center rounded-xl bg-slate-100 text-center leading-none dark:bg-slate-800">
            <b className="text-[22px] font-black">{d.getDate()}</b>
            <span className="mt-0.5 text-[11px] font-bold uppercase text-slate-500 dark:text-slate-400">{DAYS[dow(d)]}</span>
          </div>
          <div className="min-w-0">
            <h2 className="truncate text-xl font-black leading-tight">{s.title || 'Tréning'}</h2>
            <div className="text-sm text-slate-500 dark:text-slate-400">{DAYL[dow(d)]} · {ex.length} cvikov</div>
          </div>
        </button>
        <button onClick={onToggle}
          className={`flex h-11 shrink-0 items-center gap-1 rounded-full px-4 text-sm font-bold transition active:scale-95 ${done ? 'bg-green-100 text-green-700 dark:bg-green-950 dark:text-green-400' : 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-300'}`}>
          {done ? <><Check size={16} /> Hotovo</> : 'Plán'}
        </button>
      </div>
      <button onClick={onOpen} className="grid w-full gap-3 px-4 pb-4 text-left">
        {ex.length === 0 && <p className="text-sm text-slate-500">Zatiaľ bez cvikov. Ťukni a pridaj ich.</p>}
        {SECTIONS.map(({ key }) => {
          const g = ex.filter((e) => e.section === key)
          if (!g.length) return null
          return (
            <div key={key}>
              <Pill section={key} />
              <div className="mt-1 divide-y divide-slate-100 dark:divide-slate-800">
                {g.map((e, i) => (
                  <div key={i} className="flex items-baseline justify-between gap-3 py-1.5">
                    <span className="min-w-0 break-words font-medium">{e.name}</span>
                    <span className="max-w-[48%] shrink-0 break-words text-right font-bold tabular-nums">{e.dose}</span>
                  </div>
                ))}
              </div>
            </div>
          )
        })}
        {s.note && <div className="whitespace-pre-wrap rounded-xl bg-slate-100 px-3 py-2 text-sm text-slate-600 dark:bg-slate-800 dark:text-slate-300">{s.note}</div>}
      </button>
    </article>
  )
}

/* ================= Editor tréningu ================= */
function Editor({ session, weekStart, sessions, onClose, onSave, onDuplicate, onDelete }) {
  const [draft, setDraft] = useState(() => {
    if (session) return JSON.parse(JSON.stringify(session))
    const t = new Date()
    const date = iso(mondayOf(t)) === iso(weekStart) ? iso(t) : iso(weekStart)
    return { id: uid(), date, title: '', status: 'planned', note: '', exercises: [] }
  })
  const [reorder, setReorder] = useState(false)
  const [confirmDel, setConfirmDel] = useState(false)
  const focusRef = useRef(null)
  const wantFocus = useRef(false)
  useEffect(() => { if (wantFocus.current && focusRef.current) { focusRef.current.focus(); wantFocus.current = false; focusRef.current = null } })

  const names = useMemo(() => {
    const m = new Map()
    sessions.forEach((s) => s.exercises.forEach((e) => { const n = e.name.trim(); if (n && !m.has(n.toLowerCase())) m.set(n.toLowerCase(), n) }))
    return [...m.values()].sort((a, b) => a.localeCompare(b, 'sk'))
  }, [sessions])

  const set = (patch) => setDraft((d) => ({ ...d, ...patch }))
  const setEx = (i, patch) => setDraft((d) => ({ ...d, exercises: d.exercises.map((e, j) => (j === i ? { ...e, ...patch } : e)) }))
  const removeEx = (i) => setDraft((d) => ({ ...d, exercises: d.exercises.filter((_, j) => j !== i) }))
  const addEx = (section) => setDraft((d) => ({ ...d, exercises: [...d.exercises, { section, name: '', dose: '' }] }))
  const moveEx = (i, dir) => setDraft((d) => {
    const ex = [...d.exercises], k = ex[i].section
    let j = i + dir
    while (j >= 0 && j < ex.length && ex[j].section !== k) j += dir
    if (j < 0 || j >= ex.length) return d
    ;[ex[i], ex[j]] = [ex[j], ex[i]]
    return { ...d, exercises: ex }
  })
  const toSection = (i, section) => setDraft((d) => {
    const ex = [...d.exercises]
    const [item] = ex.splice(i, 1)
    return { ...d, exercises: [...ex, { ...item, section }] }
  })

  return (
    <Sheet title={session ? 'Upraviť tréning' : 'Nový tréning'} onClose={onClose}
      actions={<button className={`${btnPri} h-11`} onClick={() => onSave(draft)}>Uložiť</button>}>
      <div className="grid grid-cols-[auto,1fr] gap-2">
        <input type="date" className={`${input} w-auto`} value={draft.date} onChange={(e) => set({ date: e.target.value || draft.date })} aria-label="Dátum" />
        <input className={input} value={draft.title} onChange={(e) => set({ title: e.target.value })} placeholder="Názov, napr. Jednotka A" aria-label="Názov" />
      </div>

      <div className={`${card} grid grid-cols-2 gap-1 p-1`}>
        {[['planned', 'Plán'], ['done', 'Odcvičené']].map(([v, l]) => (
          <button key={v} onClick={() => set({ status: v })}
            className={`h-11 rounded-xl font-bold ${draft.status === v ? (v === 'done' ? 'bg-green-100 text-green-700 dark:bg-green-950 dark:text-green-400' : 'bg-slate-100 dark:bg-slate-800') : 'text-slate-500'}`}>
            {v === 'done' && '✓ '}{l}
          </button>
        ))}
      </div>

      <div className="flex justify-end">
        <button onClick={() => setReorder((r) => !r)}
          className={`flex h-10 items-center gap-2 rounded-full px-4 text-sm font-bold ${reorder ? 'bg-accent text-white' : 'bg-white text-slate-700 ring-1 ring-slate-200 dark:bg-slate-900 dark:text-slate-200 dark:ring-slate-800'}`}>
          <ListOrdered size={16} /> {reorder ? 'Hotovo' : 'Zmeniť poradie'}
        </button>
      </div>

      {SECTIONS.map(({ key }) => {
        const idx = draft.exercises.map((_, i) => i).filter((i) => draft.exercises[i].section === key)
        return (
          <div key={key} className={`${card} px-3 pb-1 pt-3`}>
            <Pill section={key} />
            <div className="mt-2 grid gap-1.5">
              {idx.map((i, p) => {
                const e = draft.exercises[i]
                return (
                  <div key={i} className="flex items-center gap-1.5">
                    <input ref={(el) => { if (el && wantFocus.current && i === draft.exercises.length - 1) focusRef.current = el }}
                      className="h-11 min-w-0 flex-1 rounded-lg bg-slate-100 px-3 dark:bg-slate-800" list="ex-names"
                      value={e.name} onChange={(ev) => setEx(i, { name: ev.target.value })} placeholder="Cvik" aria-label="Cvik" />
                    {reorder ? (
                      <>
                        <button className="grid h-11 w-10 place-items-center rounded-lg text-slate-500 disabled:opacity-30" disabled={p === 0} onClick={() => moveEx(i, -1)} aria-label="Vyššie"><ArrowUp size={18} /></button>
                        <button className="grid h-11 w-10 place-items-center rounded-lg text-slate-500 disabled:opacity-30" disabled={p === idx.length - 1} onClick={() => moveEx(i, 1)} aria-label="Nižšie"><ArrowDown size={18} /></button>
                        <select className="h-11 w-24 rounded-lg bg-slate-100 px-1 text-sm dark:bg-slate-800" value={key} onChange={(ev) => toSection(i, ev.target.value)} aria-label="Presunúť do sekcie">
                          {SECTIONS.map((s) => <option key={s.key} value={s.key}>{s.key === key ? 'Presunúť' : s.label}</option>)}
                        </select>
                      </>
                    ) : (
                      <input className="h-11 w-28 min-w-0 rounded-lg bg-slate-100 px-3 font-bold tabular-nums dark:bg-slate-800"
                        value={e.dose} onChange={(ev) => setEx(i, { dose: ev.target.value })} placeholder="3x10" aria-label="Dávkovanie" />
                    )}
                    <button className="grid h-11 w-10 shrink-0 place-items-center rounded-lg text-slate-400 active:text-red-600" onClick={() => removeEx(i)} aria-label="Vymazať cvik"><X size={20} /></button>
                  </div>
                )
              })}
            </div>
            <button className="flex h-11 items-center gap-1 text-sm font-bold text-accent" onClick={() => { setReorder(false); wantFocus.current = true; addEx(key) }}><Plus size={16} /> Pridať cvik</button>
          </div>
        )
      })}
      <datalist id="ex-names">{names.map((n) => <option key={n} value={n} />)}</datalist>

      <textarea className={input} rows={3} value={draft.note} onChange={(e) => set({ note: e.target.value })} placeholder="Poznámky – ako to išlo, čo zmeniť" aria-label="Poznámky" />

      {session && (
        <div className="grid grid-cols-2 gap-2">
          <button className={`${btnSec} flex items-center justify-center gap-2 px-2`} onClick={() => onDuplicate(draft)}><Copy size={18} /> O týždeň ďalej</button>
          <button className="flex h-12 items-center justify-center gap-2 rounded-xl font-bold text-red-600 ring-1 ring-slate-200 dark:ring-slate-800" onClick={() => setConfirmDel(true)}><Trash2 size={18} /> Vymazať</button>
        </div>
      )}
      {confirmDel && (
        <div className={`${card} grid gap-3 p-4 ring-red-300`}>
          <p className="font-semibold">Naozaj vymazať celý tréning? Nedá sa to vrátiť.</p>
          <div className="grid grid-cols-2 gap-2">
            <button className="h-12 rounded-xl bg-red-600 font-bold text-white" onClick={() => onDelete(draft.id)}>Áno, vymazať</button>
            <button className={btnSec} onClick={() => setConfirmDel(false)}>Nechať</button>
          </div>
        </div>
      )}
    </Sheet>
  )
}

/* ================= Vloženie textu ================= */
function PasteSheet({ fallbackDate, onClose, onImport }) {
  const [text, setText] = useState('')
  const [parsed, setParsed] = useState(null)
  return (
    <Sheet title="Vložiť text" onClose={onClose}>
      <p className="text-sm text-slate-500 dark:text-slate-400">
        Skopíruj tréningy z dokumentu a vlož ich sem. Rozpoznám dátum jednotky aj sekcie WU, Mobilita, Plyo, Hlavná časť a Kapacita.
      </p>
      <textarea className={input} rows={10} value={text} onChange={(e) => { setText(e.target.value); setParsed(null) }}
        placeholder={'Tréningová jednotka A (9.11.2026):\nWU\n- Glute bridge - 10x\nPLYO\n- CMJ - 2x5\nHlavná časť\n- RDL 5x5 35 kg'} />
      <button className={btnSec} onClick={() => setParsed(parseText(text, fallbackDate))}>Načítať</button>
      {parsed && (parsed.length ? (
        <>
          <div className={`${card} divide-y divide-slate-100 px-4 dark:divide-slate-800`}>
            {parsed.map((s) => {
              const d = parseDate(s.date)
              return (
                <div key={s.id} className="flex justify-between gap-3 py-3">
                  <b>{s.title}</b>
                  <span className="text-sm text-slate-500">{DAYS[dow(d)]} {fmt(d)} · {s.exercises.length} cvikov</span>
                </div>
              )
            })}
          </div>
          <button className={btnPri} onClick={() => onImport(parsed)}>Uložiť ({parsed.length})</button>
        </>
      ) : <p className="font-semibold text-red-600">V texte som nenašiel žiadne cviky.</p>)}
    </Sheet>
  )
}

/* ================= Kalendár ================= */
function CalendarView({ client, calMonth, setCalMonth, byDate, sessions, onDay }) {
  const y = calMonth.getFullYear(), m = calMonth.getMonth()
  const first = mondayOf(calMonth)
  const today = iso(new Date())
  const cells = []
  for (let i = 0; i < 42; i++) {
    const d = addDays(first, i)
    if (i >= 35 && d.getMonth() !== m) break
    cells.push(d)
  }
  const inMonth = sessions.filter((s) => s.date.startsWith(`${y}-${pad(m + 1)}`))
  const shift = (n) => setCalMonth(new Date(y, m + n, 1))

  return (
    <div className="pt-safe">
      <div className="flex items-center gap-3 pb-4 pt-5">
        <button className={iconBtn} onClick={() => shift(-1)} aria-label="Predchádzajúci mesiac"><ChevronLeft size={22} /></button>
        <div className="min-w-0 flex-1 text-center"><h1 className="text-2xl font-black">{MONL[m]} {y}</h1><div className="truncate text-sm font-semibold text-slate-500">{client.name}</div></div>
        <button className={iconBtn} onClick={() => shift(1)} aria-label="Ďalší mesiac"><ChevronRight size={22} /></button>
      </div>
      <div className={`${card} p-3`}>
        <div className="grid grid-cols-7 gap-1">
          {DAYS.map((d) => <div key={d} className="pb-1 text-center text-[11px] font-bold uppercase text-slate-500">{d}</div>)}
          {cells.map((d) => {
            const k = iso(d), ss = byDate[k] || []
            const allDone = ss.length && ss.every((s) => s.status === 'done')
            return (
              <button key={k} onClick={() => onDay(k)}
                className={`flex aspect-square min-w-0 flex-col items-center gap-0.5 rounded-xl pt-1.5 font-semibold
                  ${d.getMonth() !== m ? 'opacity-35' : ''}
                  ${ss.length ? (allDone ? 'bg-green-100 dark:bg-green-950' : 'bg-slate-100 dark:bg-slate-800') : ''}`}>
                <span className={k === today ? 'rounded-full bg-accent px-2 text-white' : ''}>{d.getDate()}</span>
                {ss.length > 0 && (
                  <>
                    <span className="flex gap-0.5">{ss.map((s) => <i key={s.id} className={`h-1.5 w-1.5 rounded-full ${s.status === 'done' ? 'bg-green-600' : 'bg-slate-400'}`} />)}</span>
                    <em className="max-w-full truncate text-[10px] font-extrabold not-italic text-slate-500">{ss.map((s) => s.title.replace(/^Jednotka\s*/i, '')).join(',')}</em>
                  </>
                )}
              </button>
            )
          })}
        </div>
        <div className="mt-3 flex justify-center gap-4 text-xs text-slate-500">
          <span className="flex items-center gap-1.5"><i className="h-2 w-2 rounded-full bg-slate-400" />Plán</span>
          <span className="flex items-center gap-1.5"><i className="h-2 w-2 rounded-full bg-green-600" />Odcvičené</span>
        </div>
      </div>
      <div className="mt-3 grid grid-cols-2 gap-3">
        <Tile label="Tréningy v mesiaci" value={inMonth.length} />
        <Tile label="Odcvičené" value={inMonth.filter((s) => s.status === 'done').length} />
      </div>
    </div>
  )
}

function Tile({ label, value }) {
  return (
    <div className={`${card} px-4 py-3`}>
      <div className="text-xs font-semibold text-slate-500 dark:text-slate-400">{label}</div>
      <div className="text-3xl font-black tabular-nums">{value}</div>
    </div>
  )
}

/* ================= Progres ================= */
function ProgressView({ client, sessions, onOpen }) {
  const names = useMemo(() => {
    const m = new Map()
    sessions.forEach((s) => s.exercises.forEach((e) => { const n = e.name.trim(); if (n && !m.has(n.toLowerCase())) m.set(n.toLowerCase(), n) }))
    return [...m.values()].sort((a, b) => a.localeCompare(b, 'sk'))
  }, [sessions])
  const [pick, setPick] = useState('')
  const current = names.find((n) => n === pick) || names[0] || ''
  const rows = []
  sessions.forEach((s) => s.exercises.forEach((e) => { if (e.name.trim().toLowerCase() === current.toLowerCase()) rows.push({ s, e }) }))
  rows.sort((a, b) => b.s.date.localeCompare(a.s.date))
  const maxKg = Math.max(0, ...rows.filter((r) => r.s.status === 'done').map((r) => kgOf(r.e.dose)))

  return (
    <div className="pt-safe">
      <h1 className="pt-5 text-2xl font-black">Progres cviku</h1><div className="pb-3 text-sm font-semibold text-slate-500">{client.name}</div>
      {!names.length ? <Empty title="Zatiaľ žiadna história">Po prvých tréningoch tu uvidíš vývoj každého cviku.</Empty> : (
        <>
          <select className={input} value={current} onChange={(e) => setPick(e.target.value)} aria-label="Vyber cvik">
            {names.map((n) => <option key={n}>{n}</option>)}
          </select>
          <div className="mt-3 grid grid-cols-2 gap-3">
            <Tile label="Najvyššia váha (odcvičené)" value={maxKg ? `${maxKg} kg` : '–'} />
            <Tile label="Záznamy" value={rows.length} />
          </div>
          <div className="mt-3 grid gap-2">
            {rows.map(({ s, e }, i) => {
              const d = parseDate(s.date)
              return (
                <button key={s.id + i} onClick={() => onOpen(s)} className={`${card} flex min-h-[52px] items-center gap-3 px-4 text-left`}>
                  <span className="w-14 shrink-0 text-sm font-bold tabular-nums text-slate-500">{pad(d.getDate())}.{pad(d.getMonth() + 1)}.</span>
                  <span className="min-w-0 flex-1 break-words font-bold tabular-nums">{e.dose || '–'}</span>
                  {s.status !== 'done' && <span className="rounded-full bg-slate-100 px-2 py-0.5 text-xs font-bold text-slate-500 dark:bg-slate-800">Plán</span>}
                </button>
              )
            })}
          </div>
        </>
      )}
    </div>
  )
}

/* ================= Nastavenia: záloha ================= */
function SettingsView({ data, setData, setToast }) {
  const fileRef = useRef(null)
  const [pending, setPending] = useState(null) // importované dáta čakajúce na potvrdenie
  const [error, setError] = useState('')
  const [confirmWipe, setConfirmWipe] = useState(false)

  const exportData = async () => {
    const json = JSON.stringify({ ...data, exportedAt: new Date().toISOString() }, null, 2)
    const name = `trening-dennik-${iso(new Date())}.json`
    const file = new File([json], name, { type: 'application/json' })
    // Na mobile ponúkne zdieľanie (uložiť do Súborov, poslať trénerovi…), inak klasické stiahnutie
    try {
      if (navigator.canShare?.({ files: [file] })) { await navigator.share({ files: [file], title: 'Záloha tréningov' }); return }
    } catch (e) { if (e?.name === 'AbortError') return }
    const url = URL.createObjectURL(file)
    const a = document.createElement('a')
    a.href = url; a.download = name
    document.body.appendChild(a); a.click(); a.remove()
    setTimeout(() => URL.revokeObjectURL(url), 1000)
    setToast('Záloha stiahnutá')
  }

  const readFile = (file) => {
    setError('')
    const r = new FileReader()
    r.onload = () => {
      try {
        const d = JSON.parse(String(r.result))
        const list = Array.isArray(d) ? d : d.sessions
        if (!Array.isArray(list)) throw new Error()
        setPending({ clients: Array.isArray(d.clients) ? d.clients.map(cleanClient) : [], sessions: list.map(cleanSession) })
      } catch { setError('Súbor nie je platná záloha tréningov (JSON).') }
    }
    r.readAsText(file)
  }

  const applyImport = (mode) => {
    if (mode === 'replace') {
      setData((d) => normalizeData({ ...pending, settings: d.settings, activeClientId: d.activeClientId }))
    } else {
      // Zlúčenie: klienti a tréningy s rovnakým id sa spoja (novšia verzia tréningu vyhrá), nové sa pridajú
      setData((d) => {
        const cmap = new Map(d.clients.map((c) => [c.id, c]))
        pending.clients.forEach((c) => { if (!cmap.has(c.id)) cmap.set(c.id, c) })
        const smap = new Map(d.sessions.map((s) => [s.id, s]))
        pending.sessions.forEach((s0) => {
          const s = { ...s0, clientId: cmap.has(s0.clientId) ? s0.clientId : d.activeClientId }
          const old = smap.get(s.id)
          if (!old || (s.updatedAt || 0) >= (old.updatedAt || 0)) smap.set(s.id, s)
        })
        return { ...d, clients: [...cmap.values()], sessions: [...smap.values()] }
      })
    }
    setToast(`Načítané tréningy: ${pending.sessions.length}`)
    setPending(null)
  }


  return (
    <div className="pt-safe">
      <h1 className="pb-3 pt-5 text-2xl font-black">Nastavenia</h1>
      <div className="grid grid-cols-2 gap-3">
        <Tile label="Klienti" value={data.clients.length} />
        <Tile label="Tréningy spolu" value={data.sessions.length} />
      </div>

      <section className={`${card} mt-4 grid gap-3 p-4`}>
        <div>
          <h2 className="text-lg font-extrabold">Záloha dát</h2>
          <p className="text-sm text-slate-500 dark:text-slate-400">
            Tréningy všetkých klientov sa ukladajú len v tomto telefóne. Raz za čas si sprav zálohu – ak sa vymaže pamäť prehliadača, obnovíš ich zo súboru.
          </p>
        </div>
        <button className={`${btnPri} flex items-center justify-center gap-2`} onClick={exportData}><Download size={20} /> Exportovať dáta (JSON)</button>
        <button className={`${btnSec} flex items-center justify-center gap-2`} onClick={() => fileRef.current?.click()}><Upload size={20} /> Importovať dáta (JSON)</button>
        <input ref={fileRef} type="file" accept="application/json,.json" className="hidden"
          onChange={(e) => { const f = e.target.files?.[0]; if (f) readFile(f); e.target.value = '' }} />
        {error && <p className="text-sm font-semibold text-red-600">{error}</p>}
        {pending && (
          <div className="grid gap-2 rounded-xl bg-slate-100 p-3 dark:bg-slate-800">
            <p className="font-semibold">V súbore je {pending.sessions.length} tréningov{pending.clients.length ? ` (klienti: ${pending.clients.map((c) => c.name).join(', ')})` : ''}. Ako ich načítať?</p>
            <button className={btnPri} onClick={() => applyImport('merge')}>Pridať k mojim (odporúčané)</button>
            <button className="h-12 rounded-xl font-bold text-red-600 ring-1 ring-slate-300 dark:ring-slate-700" onClick={() => applyImport('replace')}>Nahradiť všetko</button>
            <button className="h-11 font-semibold text-slate-500" onClick={() => setPending(null)}>Zrušiť</button>
          </div>
        )}
      </section>

      <section className={`${card} mt-4 grid gap-3 p-4`}>
        <h2 className="text-lg font-extrabold">Pridať na plochu</h2>
        <p className="text-sm text-slate-500 dark:text-slate-400">
          iPhone (Safari): Zdieľať → Pridať na plochu. Android (Chrome): ⋮ → Pridať na plochu / Inštalovať aplikáciu.
        </p>
      </section>

      <section className={`${card} mt-4 grid gap-3 p-4`}>
        <h2 className="text-lg font-extrabold text-red-600">Vymazať všetko</h2>
        {!confirmWipe ? (
          <button className="h-12 rounded-xl font-bold text-red-600 ring-1 ring-slate-200 dark:ring-slate-800" onClick={() => setConfirmWipe(true)}>Vymazať tréningy všetkých klientov</button>
        ) : (
          <>
            <p className="text-sm font-semibold">Naozaj? Najprv si sprav zálohu, toto sa nedá vrátiť.</p>
            <div className="grid grid-cols-2 gap-2">
              <button className="h-12 rounded-xl bg-red-600 font-bold text-white" onClick={() => { setData((d) => ({ ...d, sessions: [] })); setConfirmWipe(false); setToast('Všetko vymazané') }}>Áno, vymazať</button>
              <button className={btnSec} onClick={() => setConfirmWipe(false)}>Nechať</button>
            </div>
          </>
        )}
      </section>
    </div>
  )
}

/* ================= Klienti ================= */
const initials = (name) => name.split(/\s+/).filter(Boolean).slice(0, 2).map((w) => w[0].toUpperCase()).join('') || '?'

function ClientsView({ clients, allSessions, activeId, onSelect, onAdd, onEdit, onShare }) {
  const [name, setName] = useState('')
  const [q, setQ] = useState('')
  const today = iso(new Date())
  const submit = (e) => { e.preventDefault(); const n = name.trim(); if (!n) return; onAdd(n); setName('') }
  const list = clients
    .filter((c) => c.name.toLowerCase().includes(q.trim().toLowerCase()))
    .sort((a, b) => a.name.localeCompare(b.name, 'sk'))

  return (
    <div className="pt-safe">
      <h1 className="pb-3 pt-5 text-2xl font-black">Klienti</h1>
      <form onSubmit={submit} className="flex gap-2">
        <input className={input} value={name} onChange={(e) => setName(e.target.value)} placeholder="Meno nového klienta" aria-label="Meno nového klienta" />
        <button type="submit" className={`${btnPri} flex shrink-0 items-center gap-2 px-4`} disabled={!name.trim()}><UserPlus size={20} /> Pridať</button>
      </form>
      {clients.length > 5 && (
        <div className="relative mt-3">
          <Search size={18} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input className={`${input} pl-10`} value={q} onChange={(e) => setQ(e.target.value)} placeholder="Hľadať klienta" aria-label="Hľadať klienta" />
        </div>
      )}
      <div className="mt-4 grid gap-2">
        {list.length === 0 && <Empty title="Nikto sa nenašiel">Skús iné meno.</Empty>}
        {list.map((c) => {
          const ss = allSessions.filter((s) => s.clientId === c.id)
          const next = ss.filter((s) => s.date >= today && s.status !== 'done').sort((a, b) => a.date.localeCompare(b.date))[0]
          const active = c.id === activeId
          return (
            <div key={c.id} className={`${card} flex items-center gap-2 p-2 ${active ? 'ring-2 ring-accent dark:ring-accent-dark' : ''}`}>
              <button onClick={() => onSelect(c.id)} className="flex min-h-[56px] min-w-0 flex-1 items-center gap-3 rounded-xl px-2 text-left">
                <span className={`grid h-11 w-11 shrink-0 place-items-center rounded-full text-sm font-black ${active ? 'bg-accent text-white' : 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-300'}`}>{initials(c.name)}</span>
                <span className="min-w-0">
                  <span className="block truncate font-extrabold">{c.name}</span>
                  <span className="block truncate text-sm text-slate-500 dark:text-slate-400">
                    {ss.length} tréningov{next ? ` · ďalší ${DAYS[dow(parseDate(next.date))]} ${fmt(parseDate(next.date))}` : ''}
                  </span>
                </span>
              </button>
              <button className="grid h-11 w-11 shrink-0 place-items-center rounded-full text-accent active:bg-slate-100 dark:active:bg-slate-800" onClick={() => onShare(c)} aria-label={`Zdieľať tréningy: ${c.name}`}><Share2 size={20} /></button>
              <button className="grid h-11 w-11 shrink-0 place-items-center rounded-full text-slate-500 active:bg-slate-100 dark:active:bg-slate-800" onClick={() => onEdit(c)} aria-label={`Upraviť: ${c.name}`}><Pencil size={18} /></button>
            </div>
          )
        })}
      </div>
      <p className="mt-4 text-center text-sm text-slate-500 dark:text-slate-400">Ťukni na klienta a otvoria sa jeho tréningy.</p>
    </div>
  )
}

function ClientSheet({ client, count, canDelete, onClose, onSave, onDelete }) {
  const [name, setName] = useState(client.name)
  const [confirm, setConfirm] = useState(false)
  return (
    <Sheet title="Upraviť klienta" onClose={onClose}
      actions={<button className={`${btnPri} h-11`} disabled={!name.trim()} onClick={() => onSave(name.trim())}>Uložiť</button>}>
      <input className={input} value={name} onChange={(e) => setName(e.target.value)} aria-label="Meno klienta" />
      {canDelete && !confirm && (
        <button className="flex h-12 items-center justify-center gap-2 rounded-xl font-bold text-red-600 ring-1 ring-slate-200 dark:ring-slate-800" onClick={() => setConfirm(true)}><Trash2 size={18} /> Vymazať klienta</button>
      )}
      {confirm && (
        <div className={`${card} grid gap-3 p-4`}>
          <p className="font-semibold">Vymazať klienta {client.name} aj s jeho tréningmi ({count})? Nedá sa to vrátiť.</p>
          <div className="grid grid-cols-2 gap-2">
            <button className="h-12 rounded-xl bg-red-600 font-bold text-white" onClick={onDelete}>Áno, vymazať</button>
            <button className={btnSec} onClick={() => setConfirm(false)}>Nechať</button>
          </div>
        </div>
      )}
      {!canDelete && <p className="text-sm text-slate-500">Posledného klienta sa nedá vymazať, môžeš ho len premenovať.</p>}
    </Sheet>
  )
}

/* ================= Zdieľanie klientovi ================= */
function planText(client, list, heading) {
  const lines = [`Tréningy – ${client.name}`, heading, '']
  list.forEach((s) => {
    const d = parseDate(s.date)
    lines.push(`${(s.title || 'Tréning').toUpperCase()} – ${DAYL[dow(d)]} ${d.getDate()}. ${d.getMonth() + 1}.${s.status === 'done' ? ' ✓' : ''}`)
    SECTIONS.forEach(({ key, label }) => {
      const g = s.exercises.filter((e) => e.section === key && e.name)
      if (!g.length) return
      lines.push(label.toUpperCase())
      g.forEach((e) => lines.push(`• ${e.name}${e.dose ? ` – ${e.dose}` : ''}`))
    })
    if (s.note) lines.push(`Poznámka: ${s.note}`)
    lines.push('')
  })
  return lines.join('\n').trim()
}

function ShareSheet({ client, sessions, onClose, setToast }) {
  const [scope, setScope] = useState('this')
  const mon = mondayOf(new Date())
  const ranges = {
    this: { label: 'Tento týždeň', from: iso(mon), to: iso(addDays(mon, 6)), head: `Týždeň ${isoWeek(mon)} (${fmt(mon)} – ${fmt(addDays(mon, 6))})` },
    next: { label: 'Budúci týždeň', from: iso(addDays(mon, 7)), to: iso(addDays(mon, 13)), head: `Týždeň ${isoWeek(addDays(mon, 7))} (${fmt(addDays(mon, 7))} – ${fmt(addDays(mon, 13))})` },
    all: { label: 'Všetko', from: '0000', to: '9999', head: 'Všetky tréningy' },
  }
  const r = ranges[scope]
  const list = sessions.filter((s) => s.date >= r.from && s.date <= r.to).sort((a, b) => a.date.localeCompare(b.date))
  const text = planText(client, list, r.head)

  const shareText = async () => {
    try {
      if (navigator.share) { await navigator.share({ title: `Tréningy – ${client.name}`, text }); return }
    } catch (e) { if (e?.name === 'AbortError') return }
    copyText()
  }
  const copyText = async () => {
    try { await navigator.clipboard.writeText(text); setToast('Text skopírovaný') } catch { setToast('Kopírovanie nefunguje, označ text ručne') }
  }
  const shareFile = async () => {
    const json = JSON.stringify({ version: 2, exportedAt: new Date().toISOString(), clients: [client], sessions: list }, null, 2)
    const fname = `treningy-${client.name.toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9]+/g, '-')}-${iso(new Date())}.json`
    const file = new File([json], fname, { type: 'application/json' })
    try {
      if (navigator.canShare?.({ files: [file] })) { await navigator.share({ files: [file], title: `Tréningy – ${client.name}` }); return }
    } catch (e) { if (e?.name === 'AbortError') return }
    const url = URL.createObjectURL(file)
    const a = document.createElement('a')
    a.href = url; a.download = fname
    document.body.appendChild(a); a.click(); a.remove()
    setTimeout(() => URL.revokeObjectURL(url), 1000)
    setToast('Súbor stiahnutý')
  }

  return (
    <Sheet title={`Zdieľať – ${client.name}`} onClose={onClose}>
      <div className={`${card} grid grid-cols-3 gap-1 p-1`}>
        {Object.entries(ranges).map(([k, v]) => (
          <button key={k} onClick={() => setScope(k)} className={`h-11 rounded-xl text-sm font-bold ${scope === k ? 'bg-accent text-white' : 'text-slate-500'}`}>{v.label}</button>
        ))}
      </div>
      {list.length === 0 ? (
        <Empty title="Nič na zdieľanie">V tomto období nemá {client.name} žiadne tréningy.</Empty>
      ) : (
        <>
          <pre className={`${card} max-h-[45dvh] overflow-auto whitespace-pre-wrap break-words p-4 font-sans text-sm`}>{text}</pre>
          <button className={`${btnPri} flex items-center justify-center gap-2`} onClick={shareText}><Send size={20} /> Poslať ako správu</button>
          <button className={`${btnSec} flex items-center justify-center gap-2`} onClick={copyText}><Copy size={20} /> Kopírovať text</button>
          <button className={`${btnSec} flex items-center justify-center gap-2`} onClick={shareFile}><Download size={20} /> Poslať súbor do appky</button>
          <p className="text-sm text-slate-500 dark:text-slate-400">
            <b>Správa</b> sa dá poslať cez WhatsApp, Messenger či SMS a klient ju len prečíta.
            <b> Súbor</b> si klient načíta vo svojej appke cez Nastavenia → Importovať. Keď ti ho po tréningu pošle späť, uvidíš, čo odcvičil.
          </p>
        </>
      )}
    </Sheet>
  )
}
