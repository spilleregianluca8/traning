# Tréningový denník (PWA)

Mobilná webová aplikácia na zápis silových tréningov pre viac klientov (záložka Klienti: pridanie, prepínanie, zdieľanie tréningov). Dáta sa ukladajú v telefóne (localStorage), zálohu spravíš v Nastaveniach (Export / Import JSON).

## Štruktúra

```
trening-dennik/
├── index.html              # meta tagy pre iOS/Android, odkaz na manifest
├── package.json
├── vite.config.js
├── tailwind.config.js
├── postcss.config.js
├── vercel.json             # cache hlavičky pre sw.js a manifest
├── public/
│   ├── manifest.json       # PWA: názov, ikony, celá obrazovka
│   ├── sw.js               # offline režim
│   ├── icon-192.png
│   ├── icon-512.png
│   ├── icon-maskable-512.png
│   └── apple-touch-icon.png
└── src/
    ├── main.jsx
    ├── index.css
    └── App.jsx             # celá aplikácia
```

## Spustenie na počítači (nepovinné)

```
npm install
npm run dev
```

## Nasadenie na Vercel

1. Na github.com vytvor nový repozitár (New repository → napr. `trening-dennik` → Create).
2. Na stránke repozitára klikni „uploading an existing file“ a pretiahni tam **obsah** tohto priečinka
   (súbory a priečinky `public`, `src`, nie priečinok samotný). Potvrď „Commit changes“.
3. Na vercel.com sa prihlás cez GitHub → **Add New… → Project** → pri repozitári klikni **Import**.
4. Vercel sám rozpozná Vite (Build: `npm run build`, Output: `dist`). Klikni **Deploy**.
5. Po minúte dostaneš adresu typu `https://trening-dennik.vercel.app`.
6. Otvor ju v telefóne:
   - iPhone (Safari): Zdieľať → **Pridať na plochu**
   - Android (Chrome): ⋮ → **Pridať na plochu** / **Inštalovať aplikáciu**

Každá ďalšia zmena nahratá na GitHub sa na Verceli nasadí automaticky.

## Dôležité

- Dáta sú uložené **len v danom telefóne**. Klientovi pošleš tréningy cez Klienti → ikona zdieľania: ako text (WhatsApp, SMS) alebo ako súbor, ktorý si načíta vo svojej appke (Nastavenia → Importovať → Pridať k mojim).
- Na iPhone má aplikácia pridaná na plochu vlastné úložisko oddelené od Safari. Používaj ju vždy z ikony na ploche.
- Raz za čas si sprav zálohu (Export).
